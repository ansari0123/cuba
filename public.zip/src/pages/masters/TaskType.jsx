import React from 'react'

const TaskType = () => {
  return (
    <>
        <div className="content">
            
        </div>
    </>
  )
}

export default TaskType